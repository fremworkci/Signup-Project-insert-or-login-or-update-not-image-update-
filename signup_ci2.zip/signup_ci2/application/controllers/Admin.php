<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('sess_name'))
		{
			redirect('Signup');
		}
	}

	function index()
	{
		$sess_data=$this->session->userdata('sess_name');
		$data['email']=$sess_data['email'];
		$qry['email']=$this->Model1->select($data);
		$this->load->view('profile',$qry);
	}

	//for Edit value in text box
	function edit($id)
	{
		$data=array('id'=>$id);
		$qry['data']=$this->Model1->edit_fetch($data);
		$this->load->view('edit',$qry);
	}

	function Logout()
    {
        $this->session->unset_userdata('session_name');
        session_destroy();
        // $this->load->view('signup');
        redirect('Signup');
    }


	//for update
	function update()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$id=$this->input->post('getid');

		$data=array('name'=>$name,'email'=>$email);
		$qry=$this->Model1->update2($id,$data);
	   if($qry)
	   {
	   	redirect('admin');
	   }
	}

	


}
