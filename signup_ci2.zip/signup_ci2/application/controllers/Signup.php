<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Signup extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('signup');
	}

	//For Insert
	public function insert(){
		$name=$this->input->post("name");
		$email=$this->input->post("email");
		$password=$this->input->post("password");
		$mobile=$this->input->post("mobile");
		$gender=$this->input->post("gender");
		$dob=$this->input->post("dob");
		$city=$this->input->post("city");
		$file=$_FILES['pic']['tmp_name'];
		$destination="img/".$_FILES['pic']['name'];
		if(move_uploaded_file($file, $destination))
		{
			$img=$_FILES['pic']['name'];
		}
		$data=array('name'=>$name,'email'=>$email,'password'=>$password,'mobile'=>$mobile,'gender'=>$gender,'dob'=>$dob,'city'=>$city, 'pic'=>$img);
		$qry=$this->Model1->insert_record($data);
		$this->index();
	}

	//For Login
	public function login()
	{
		$email=$this->input->post("email");
		$password=$this->input->post("password");
		$data=array('email'=>$email,'password'=>$password);
		$qry=$this->Model1->valid_login($data);
		if($qry)
		{
			//echo "Sucessss...";
			$sess_array=array();
			foreach($qry as $row)
			{
				$sess_array=array('id'=>$row->id,'email'=>$row->email);
				$this->session->set_userdata('sess_name',$sess_array);
				redirect('Admin');
			}
		}
		else
		{
			echo "Wrong...";
		}
	}
}
