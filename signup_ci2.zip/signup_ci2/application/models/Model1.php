<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model1 extends CI_Model {
	public function insert_record($data)
	{
		$qry=$this->db->insert('signup',$data);
		return $qry;
	}

	//For Login
	public function valid_login($data)
	{
		$qry=$this->db->get_where('signup',$data);
		return $qry->result();
	}

	//For Profile
	public function select($data)
	{
		$qry=$this->db->get_where('signup',$data);
		return $qry->result();
	}

	//for Edit value in text box
	function edit_fetch($data)
	{
		$qry=$this->db->get_where('signup',$data);
		return $qry->result();
	}

	//Update
	function update2($id,$data)
	{
		$this->db->where('id', $id);
		$qry=$this->db->update('signup', $data);
		return $qry;
	}



}