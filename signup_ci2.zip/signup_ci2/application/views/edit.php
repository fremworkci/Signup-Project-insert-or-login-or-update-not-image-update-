<?php
foreach($data as $row)
{
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php echo form_open("admin/update"); ?>
<table>
	<tr>
	 <input type="hidden" name="getid" value="<?php echo $row->id; ?>">
		<td>Name</td><td><input type="text" name="name" value="<?php echo $row->name; ?>"></td>
	</tr>
	<tr>
		<td>Email</td><td><input type="text" name="email" value="<?php echo $row->email; ?>"></td>
	</tr>
	<tr>
		<td><input type="submit"  value="Update"></td>
	</tr>
</table>
<?php  echo form_close();  ?>
</body>
</html>
<?php
}
?>