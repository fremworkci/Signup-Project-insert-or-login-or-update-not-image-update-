<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assist/css/bootstrap.min.css'); ?>">
	<title></title>
</head>
<body>
<?php echo form_open_multipart("Signup/insert"); ?>
<form class="form-horizontal" style="float: left;">
  <fieldset style="margin-left: 200px;">
    <legend>Signup Form.....</legend>
    <!--Name-->
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">Name</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputEmail" name="name" placeholder="Name" style="width: 300px;">
      </div>
    </div>
    <!--Email-->
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">Email</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputEmail" name="email" placeholder="Email" style="width: 300px;">
      </div>
    </div>
    <!--Password-->
    <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label">Password</label>
      <div class="col-lg-10">
        <input type="password" class="form-control" id="inputPassword" name="password" placeholder="Password" style="width: 300px;">
      </div>
    </div>
    <!--Adress-->
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">Date</label>
      <div class="col-lg-10">
        <input type="date" class="form-control" id="inputEmail" name="dob" placeholder="Date" style="width: 300px;">
      </div>
    </div>

    <!--Mobilee-->
    <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label">Mobile</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputPassword" name="mobile" placeholder="Mobile" style="width: 300px;">

      </div>
    </div>
    <!--Gender-->
    <div class="form-group">
      <label class="col-lg-2 control-label">Gender</label>
      <div class="col-lg-10">
        <div class="radio">
          <label>
            <input type="radio"  id="optionsRadios1" name="gender" value="male" checked="">
           Male
          </label>
        </div>
        <div class="radio">
          <label>
            <input type="radio" id="optionsRadios2" name="gender" value="female">
            Female
          </label>
        </div>
      </div>
    </div>
    <!--City-->
    <div class="form-group">
      <label for="select" class="col-lg-2 control-label" >Selects</label>
      <div class="col-lg-10">
        <select class="form-control" id="select" name="city" style="width: 300px;">
          <option value="patna">Patna</option>
          <option value="Danapur">Danapur</option>
          <option value="Phulwari">Phulwari</option>
          <option value="Sadisopur">Sadisopur</option>
          <option value="Gopalpur">Gopalpur</option>
        </select>
        
      </div>
    </div>
    <!--Pic-->
    <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label">Image</label>
      <div class="col-lg-10">
        <input type="file" class="form-control" id="inputPassword" name="pic" style="width: 300px;">

      </div>
    </div>

    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
        <button type="reset" class="btn btn-default">Cancel</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </fieldset>
</form>
<?php echo form_close(); ?>



<!--For Login-->
<span style="float: right;">
<?php echo form_open("Signup/login"); ?>
<form class="form-horizontal" style="float: right;">
  <fieldset style="margin-left: 100px;margin-top: -419px;">
    <legend>Login Form.....</legend>
    <!--Name-->
    
    <!--Email-->
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">Email</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" id="inputEmail" name="email" placeholder="Email" style="width: 300px;">
      </div>
    </div>
    <!--Password-->
    <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label">Password</label>
      <div class="col-lg-10">
        <input type="password" class="form-control" id="inputPassword" name="password" placeholder="Password" style="width: 300px;">
      </div>
    </div>
    
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
        <button type="reset" class="btn btn-default">Cancel</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </fieldset>
</form>
<?php echo form_close(); ?>
</span>
</body>
</html>